function setSimulationInput(input)
handles=find_system('simulinkModel','FindAll','On','SearchDepth',1,'BlockType','Constant');

for i = 1:numel(handles)

    set_param(handles(i), 'Value', num2str(input(i)));
    input_names{i,:} = get_param(handles(i), 'Name'); 
end

% [t, x, y] = sim('simulinkModel');
% a = sim('simulinkModel')

