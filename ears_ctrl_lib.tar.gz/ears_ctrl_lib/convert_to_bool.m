function output= convert_to_bool(condition_string)
if strcmp(condition_string,'false')
     output = false;
   else
     output = true;
   end
end