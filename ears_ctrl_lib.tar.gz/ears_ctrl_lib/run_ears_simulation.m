
function run_ears_simulation(depth, allow_same_output, allow_same_intput,filePath)


% load_system('simulinkModel');
% close_system('simulinkModel');

handles=find_system('simulinkModel','FindAll','On','SearchDepth',1,'BlockType','Constant'); 
for i = 1:numel(handles)
    input_names{i,:} = get_param(handles(i), 'Name'); 
end

handles=find_system('simulinkModel','FindAll','On','SearchDepth',1,'BlockType','Outport'); 
for i = 1:numel(handles)
    output_names{i,:} = get_param(handles(i), 'Name'); 
end

completeFilePath = strcat(cellstr(filePath),'/testCaseResult.txt');
tokenFilePath = strcat(cellstr(filePath),'/token');
if exist(char(tokenFilePath), 'file') == 2
    delete tokenFilePath;
end


disp(completeFilePath)

if exist(char(completeFilePath), 'file') == 2
    delete completeFilePath;
end
fid=fopen(completeFilePath{:},'w');
fprintf(fid, 'INPUT: \n');
fprintf(fid, '%s \n', input_names{:});
fprintf(fid, 'END INPUT: \n');
fprintf(fid, 'OUTPUT: \n');
fprintf(fid, '%s \n', output_names{:});
fprintf(fid, 'END OUTPUT: \n');

% depth = 3;
size_input = size(input_names);
number_of_input = size_input(1);
 M = permn([1 0], number_of_input);

 [row_M , column_M] =  size(M);
 
row_num = 1;
 while row_num <= column_M
     if sum(M(row_num,:)) ~= 1
         M(row_num,:)=[];
     else row_num = row_num + 1;
     end
 end
 
 M(end,:)=[];
 
%  disp('the value of M is ..')
%  disp(M)
 
a =permn(1:number_of_input, str2num(depth));


[r, c] = size(a);
for row = 1:r
    for col = 1:c
        final_matrix(:,:,row,col) = M(a(row,col),:);
    end
end




 count = 0;

for row_num = 1:r
    load_system('simulinkModel');
    
    last_output = [];
    same_input = true;
    out_text = {};
    out_text{length(out_text)+1} = 'START SEQUENCE';
    for column_num = 1:c
        
        if ~convert_to_bool(allow_same_intput)
            row_extract = a(row_num,:);
            for i = 1:length(row_extract)
                if i >1 && (row_extract(i-1) == row_extract(i))
                    same_input = false;
                    break;
                end
            end
        end
        
        if same_input == false
            break;
        end
        N = final_matrix(:,:,row_num,column_num);
        
%         disp('the value of count is ')
%         disp(count)
%         count = count +1;
%         disp(N)
        
        setSimulationInput(N);
        [t, x, y] = sim('simulinkModel');
        
        if ~convert_to_bool(allow_same_output) && isequal(int8(y), last_output)
            break;
        end
        
        out_text{length(out_text)+1} = 'The inputs are: ';
        out_text{length(out_text)+1} = num2str(N);
        out_text{length(out_text)+1} = 'The outputs are: ';
        out_text{length(out_text)+1} = num2str(int8(y));
        
%         fprintf(fid, 'The inputs are: \n');
%         fprintf(fid, '%d \n', N);
%         
%         fprintf(fid, 'The outputs are: \n');
%         
%         
%         fprintf(fid, '%d \n', int8(y));
        if column_num == c
            fprintf(fid, '%s \n', out_text{:});
            fprintf(fid, 'END SEQUENCE \n');
        end
        last_output = int8(y);
        
    end
    clear trub_block_gxw;
    clear generic_event_block_gxw;
end

fclose(fid);

% close_system('simulinkModel', 0);
% open_system('simulinkModel');

fid=fopen(tokenFilePath{:},'w');
fclose(fid);

